GRM.Server.Log("Server Started via Lua!")
print("Version: " .. GRM.GetVersion())

local count = GRM.Player.GetCount()
if count > 100 then
    GRM.Server.Shutdown()
end
