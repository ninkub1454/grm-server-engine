ResourceManifest(
    name: "core_system",
    author: "Ninkub",
    version: "1.0.0",
    resource_type: "scripts",

    server_scripts: ["server.lua"],
)
